-- ===================================================================
-- CHỈ CHÈN DỮ LIỆU MẪU NẾU BẢNG CHƯA CÓ DỮ LIỆU (an toàn tuyệt đối)
-- ===================================================================

-- =============== USERS - 10 khách hàng mẫu ===============
INSERT INTO users (name, email)
SELECT * FROM (SELECT
                   'Nguyễn Văn An',        'an.nguyen@gmail.com'
              ) AS tmp WHERE NOT EXISTS (
    SELECT 1 FROM users WHERE email = 'an.nguyen@gmail.com'
) LIMIT 1;

INSERT INTO users (name, email)
SELECT * FROM (SELECT 'Trần Thị Bé',         'be.tran@yahoo.com') AS tmp
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'be.tran@yahoo.com') LIMIT 1;

INSERT INTO users (name, email)
SELECT * FROM (SELECT 'Lê Minh Châu',       'chau.le@hotmail.com') AS tmp
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'chau.le@hotmail.com') LIMIT 1;

INSERT INTO users (name, email)
SELECT * FROM (SELECT 'Phạm Quốc Cường',    'cuong.pham@gmail.com') AS tmp
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'cuong.pham@gmail.com') LIMIT 1;

INSERT INTO users (name, email)
SELECT * FROM (SELECT 'Hoàng Thị Dung',     'dung.hoang@gmail.com') AS tmp
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'dung.hoang@gmail.com') LIMIT 1;

INSERT INTO users (name, email)
SELECT * FROM (SELECT 'Vũ Văn Em',          'em.vu@outlook.com') AS tmp
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'em.vu@outlook.com') LIMIT 1;

INSERT INTO users (name, email)
SELECT * FROM (SELECT 'Đỗ Thị Phương',      'phuong.do@gmail.com') AS tmp
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'phuong.do@gmail.com') LIMIT 1;

INSERT INTO users (name, email)
SELECT * FROM (SELECT 'Bùi Quang Huy',      'huy.bui@gmail.com') AS tmp
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'huy.bui@gmail.com') LIMIT 1;

INSERT INTO users (name, email)
SELECT * FROM (SELECT 'Mai Thị Lan',        'lan.mai@gmail.com') AS tmp
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'lan.mai@gmail.com') LIMIT 1;

INSERT INTO users (name, email)
SELECT * FROM (SELECT 'Trương Văn Khánh',   'khanh.truong@gmail.com') AS tmp
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'khanh.truong@gmail.com') LIMIT 1;


-- =============== PRODUCTS - 10 sản phẩm mẫu ===============
INSERT INTO products (name, price, image_url, description)
SELECT * FROM (SELECT
                   'iPhone 16 Pro Max 256GB', 34990000, 'https://example.com/iphone16.jpg', 'Chip A19, camera 48MP'
              ) AS tmp WHERE NOT EXISTS (
    SELECT 1 FROM products WHERE name = 'iPhone 16 Pro Max 256GB'
) LIMIT 1;

INSERT INTO products (name, price, image_url, description)
SELECT * FROM (SELECT 'MacBook Pro M4 16GB', 58990000, 'https://example.com/macbook.jpg', 'Siêu mạnh cho developer') AS tmp
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'MacBook Pro M4 16GB') LIMIT 1;

INSERT INTO products (name, price, image_url, description)
SELECT * FROM (SELECT 'Tai nghe AirPods Pro 2', 6490000, 'https://example.com/airpods.jpg', 'Chống ồn chủ động') AS tmp
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Tai nghe AirPods Pro 2') LIMIT 1;

INSERT INTO products (name, price, image_url, description)
SELECT * FROM (SELECT 'Ốp lưng iPhone trong suốt', 250000, 'https://example.com/case.jpg', 'Chống sốc, siêu mỏng') AS tmp
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Ốp lưng iPhone trong suốt') LIMIT 1;

INSERT INTO products (name, price, image_url, description)
SELECT * FROM (SELECT 'Sạc nhanh 65W GaN', 890000, 'https://example.com/charger.jpg', 'Sạc đa năng') AS tmp
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Sạc nhanh 65W GaN') LIMIT 1;

INSERT INTO products (name, price, image_url, description)
SELECT * FROM (SELECT 'Bàn phím cơ Keychron K2', 2190000, 'https://example.com/keychron.jpg', 'Switch Gateron Red') AS tmp
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Bàn phím cơ Keychron K2') LIMIT 1;

INSERT INTO products (name, price, image_url, description)
SELECT * FROM (SELECT 'Chuột Logitech MX Master 3S', 2790000, 'https://example.com/mxmaster.jpg', 'Công thái học') AS tmp
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Chuột Logitech MX Master 3S') LIMIT 1;

INSERT INTO products (name, price, image_url, description)
SELECT * FROM (SELECT 'Màn hình Dell UltraSharp 27" 4K', 12990000, 'https://example.com/dell4k.jpg', '100% sRGB') AS tmp
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Màn hình Dell UltraSharp 27" 4K') LIMIT 1;

INSERT INTO products (name, price, image_url, description)
SELECT * FROM (SELECT 'Loa Bluetooth JBL Flip 6', 2990000, 'https://example.com/jbl.jpg', 'Chống nước IP67') AS tmp
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Loa Bluetooth JBL Flip 6') LIMIT 1;

INSERT INTO products (name, price, image_url, description)
SELECT * FROM (SELECT 'Đồng hồ Apple Watch Ultra 2', 21990000, 'https://example.com/watch.jpg', 'Pin 36h, GPS') AS tmp
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Đồng hồ Apple Watch Ultra 2') LIMIT 1;