// src/main/java/com/example/advertisingapp/service/EmailSenderService.java
package com.t2404e.emailmanager.service;

import com.t2404e.emailmanager.entity.EmailEntity;
import com.t2404e.emailmanager.repository.EmailRepository;
import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring6.SpringTemplateEngine;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class EmailSenderService {

    private final JavaMailSender mailSender;
    private final EmailRepository emailRepository;
    private final SpringTemplateEngine templateEngine;

    @Async
    public void sendPendingEmails() {
        emailRepository.findByStatus("CHUA_GUI")
                .forEach(this::sendSingleEmailWithTemplate);
    }

    private void sendSingleEmailWithTemplate(EmailEntity email) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
                    StandardCharsets.UTF_8.name());

            // Danh sách người nhận
            String[] recipients = email.getRecipients().toArray(new String[0]);
            helper.setTo(recipients);
            helper.setFrom("no-reply@yourshop.com");
            helper.setSubject(email.getSubject());

            // Render template
            Context context = new Context();
            context.setVariable("subject", email.getSubject());
            context.setVariable("emailContent", email.getContent());
            context.setVariable("products", email.getProducts());

            context.setVariable("customerName", "Customer Name");

            String html = templateEngine.process("email/promo-template", context);
            helper.setText(html, true);

            mailSender.send(message);

            email.setStatus("DA_GUI");
            emailRepository.save(email);
            log.info("Gửi thành công email ID: {} tới {} người", email.getId(), recipients.length);

        } catch (Exception e) {
            log.error("Lỗi gửi email ID: " + email.getId(), e);
            email.setStatus("LOI");
            emailRepository.save(email);
        }
    }
}