package com.t2404e.emailmanager.repository;

import com.t2404e.emailmanager.entity.ProductEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductRepository extends JpaRepository<ProductEntity, Long> {
    // Tìm kiếm sản phẩm theo tên (cho filter)
    List<ProductEntity> findByNameContainingIgnoreCase(String name);
}