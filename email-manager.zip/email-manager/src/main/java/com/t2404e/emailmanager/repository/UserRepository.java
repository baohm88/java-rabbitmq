package com.t2404e.emailmanager.repository;

import com.t2404e.emailmanager.entity.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<UserEntity, Long> {}