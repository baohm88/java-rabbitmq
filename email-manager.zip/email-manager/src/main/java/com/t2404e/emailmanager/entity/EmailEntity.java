package com.t2404e.emailmanager.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "emails")
@Data
public class EmailEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String subject;  // Tiêu đề
    private String content;  // Nội dung

    @ElementCollection  // Lưu danh sách email khách hàng dưới dạng list string
    @CollectionTable(name = "email_recipients", joinColumns = @JoinColumn(name = "email_id"))
    private List<String> recipients = new ArrayList<>();  // Danh sách email khách hàng

    @ManyToMany  // Quan hệ nhiều-nhiều với sản phẩm
    @JoinTable(
            name = "email_products",
            joinColumns = @JoinColumn(name = "email_id"),
            inverseJoinColumns = @JoinColumn(name = "product_id")
    )
    private List<ProductEntity> products = new ArrayList<>();  // Danh sách sản phẩm quảng cáo

    private String status = "CHUA_GUI";  // Trạng thái: CHUA_GUI, DA_GUI, LOI,...

    @CreationTimestamp
    private LocalDateTime createdAt;  // Thời gian tạo
}