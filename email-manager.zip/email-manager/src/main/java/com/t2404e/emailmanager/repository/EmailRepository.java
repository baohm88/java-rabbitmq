package com.t2404e.emailmanager.repository;

import com.t2404e.emailmanager.entity.EmailEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmailRepository extends JpaRepository<EmailEntity, Long> {
    List<EmailEntity> findByStatus(String status);
}

