package com.t2404e.emailmanager.service;

import com.t2404e.emailmanager.entity.EmailEntity;
import com.t2404e.emailmanager.entity.ProductEntity;
import com.t2404e.emailmanager.entity.UserEntity;
import com.t2404e.emailmanager.repository.EmailRepository;
import com.t2404e.emailmanager.repository.ProductRepository;
import com.t2404e.emailmanager.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor  // Lombok
public class EmailService {

    private final EmailRepository emailRepository;
    private final UserRepository userRepository;
    private final ProductRepository productRepository;

    // Lấy tất cả khách hàng cho form
    public List<UserEntity> getAllUsers() {
        return userRepository.findAll();
    }

    // Lấy tất cả sản phẩm hoặc filter theo tên
    public List<ProductEntity> getProducts(String search) {
        if (search == null || search.isEmpty()) {
            return productRepository.findAll();
        }
        return productRepository.findByNameContainingIgnoreCase(search);
    }

    // Lưu email mới vào DB
    public void saveEmail(String subject, String content, List<Long> userIds, List<Long> productIds) {
        EmailEntity email = new EmailEntity();
        email.setSubject(subject);
        email.setContent(content);
        email.setStatus("CHUA_GUI");

        // Lấy email từ userIds
        List<String> recipients = userRepository.findAllById(userIds).stream()
                .map(UserEntity::getEmail)
                .toList();
        email.setRecipients(recipients);

        // Lấy products từ productIds
        List<ProductEntity> products = productRepository.findAllById(productIds);
        email.setProducts(products);

        emailRepository.save(email);
    }
}