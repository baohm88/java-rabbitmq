package com.t2404e.emailmanager.controller;

import com.t2404e.emailmanager.dto.CreateEmailRequest;
import com.t2404e.emailmanager.service.EmailService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/admin/emails")
@RequiredArgsConstructor
public class AdminEmailController {

    private final EmailService emailService;

    // Hiển thị form tạo email mới
    @GetMapping("/new")
    public String showCreateForm(Model model, @RequestParam(required = false) String productSearch) {
        System.out.println("Size users: "+emailService.getAllUsers().size());
        model.addAttribute("users", emailService.getAllUsers());  // Danh sách khách hàng checkbox
        model.addAttribute("products", emailService.getProducts(productSearch));  // Danh sách sản phẩm checkbox, với search
        model.addAttribute("productSearch", productSearch);  // Giữ giá trị search
        return "admin/email-form";  // Template Thymeleaf
    }

    @PostMapping(value = "/save", consumes = "application/json")
    public ResponseEntity<?> saveEmail(@RequestBody CreateEmailRequest request) {

        emailService.saveEmail(
                request.subject(),
                request.content(),
                request.userIds() != null ? request.userIds() : List.of(),
                request.productIds() != null ? request.productIds() : List.of()
        );

        return ResponseEntity.ok(Map.of("message", "Email đã được lưu thành công!"));
    }

    @GetMapping("/success")
    public String success() {
        return "admin/success";  // Trang thành công đơn giản
    }
}