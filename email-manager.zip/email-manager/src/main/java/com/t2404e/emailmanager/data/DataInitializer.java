package com.t2404e.emailmanager.data;

import com.t2404e.emailmanager.entity.ProductEntity;
import com.t2404e.emailmanager.entity.UserEntity;
import com.t2404e.emailmanager.repository.ProductRepository;
import com.t2404e.emailmanager.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final ProductRepository productRepository;

    @Override
    public void run(String... args) {
        if (userRepository.count() == 0) {
            createSampleUsers();
            System.out.println("Đã tạo 10 user mẫu!");
        }

        if (productRepository.count() == 0) {
            createSampleProducts();
            System.out.println("Đã tạo 10 sản phẩm mẫu!");
        }
    }

    private void createSampleUsers() {
        List<UserEntity> users = List.of(
                new UserEntity(null, "Nguyễn Văn An", "an.nguyen@gmail.com"),
                new UserEntity(null, "Trần Thị Bé", "be.tran@yahoo.com"),
                new UserEntity(null, "Lê Minh Châu", "chau.le@hotmail.com"),
                new UserEntity(null, "Phạm Quốc Cường", "cuong.pham@gmail.com"),
                new UserEntity(null, "Hoàng Thị Dung", "dung.hoang@gmail.com"),
                new UserEntity(null, "Vũ Văn Em", "em.vu@outlook.com"),
                new UserEntity(null, "Đỗ Thị Phương", "phuong.do@gmail.com"),
                new UserEntity(null, "Bùi Quang Huy", "huy.bui@gmail.com"),
                new UserEntity(null, "Mai Thị Lan", "lan.mai@gmail.com"),
                new UserEntity(null, "Trương Văn Khánh", "khanh.truong@gmail.com")
        );
        userRepository.saveAll(users);
    }

    private void createSampleProducts() {
        List<ProductEntity> products = List.of(
                new ProductEntity(null, "iPhone 16 Pro Max 256GB", new BigDecimal("34990000"), "https://example.com/iphone16.jpg", "Mới nhất 2025, chip A19"),
                new ProductEntity(null, "MacBook Pro M4 16GB", new BigDecimal("58990000"), "https://example.com/macbook.jpg", "Siêu mạnh cho dev"),
                new ProductEntity(null, "Tai nghe AirPods Pro 2", new BigDecimal("6490000"), "https://example.com/airpods.jpg", "Chống ồn chủ động"),
                new ProductEntity(null, "Ốp lưng iPhone trong suốt", new BigDecimal("250000"), "https://example.com/case.jpg", "Siêu mỏng"),
                new ProductEntity(null, "Sạc nhanh 65W GaN", new BigDecimal("890000"), "https://example.com/charger.jpg", "Sạc đa năng"),
                new ProductEntity(null, "Bàn phím cơ Keychron K2", new BigDecimal("2190000"), "https://example.com/keychron.jpg", "Switch Gateron"),
                new ProductEntity(null, "Chuột Logitech MX Master 3S", new BigDecimal("2790000"), "https://example.com/mxmaster.jpg", "Công thái học"),
                new ProductEntity(null, "Màn hình Dell UltraSharp 27\" 4K", new BigDecimal("12990000"), "https://example.com/dell4k.jpg", "100% sRGB"),
                new ProductEntity(null, "Loa Bluetooth JBL Flip 6", new BigDecimal("2990000"), "https://example.com/jbl.jpg", "Chống nước IP67"),
                new ProductEntity(null, "Đồng hồ Apple Watch Ultra 2", new BigDecimal("21990000"), "https://example.com/watch.jpg", "Pin 36h")
        );
        productRepository.saveAll(products);
    }
}
