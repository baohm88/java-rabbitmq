// src/main/java/com/example/advertisingapp/dto/CreateEmailRequest.java
package com.t2404e.emailmanager.dto;

import java.util.List;

public record CreateEmailRequest(
        String subject,
        String content,
        List<Long> userIds,      // Dùng Long luôn cho an toàn
        List<Long> productIds
) {}